const UrlApi = "http://172.16.0.35:5000/api";
export default UrlApi;