import React, { Component } from 'react';
import '../Usuario/editar.css';
import verificaLogin from '../../Services/Functions/verificaLogin';
class Editar extends Component {
    constructor() {
        super();
        this.state = {
            id: "",
            url: "",
            login: "",
            senha: "",
        };
    }
    componentDidMount() {
        if (verificaLogin() == false) { this.props.history.push("/login") }
    }

    atualizaUrl(event) {
        this.setState({ url: event.target.value });
    }

    atualizaLogin(event) {
        this.setState({ login: event.target.value });
    }

    atualizaSenha(event) {
        this.setState({ senha: event.target.value });
    }

    editaUsuario(event) {
        event.preventDefault();

        fetch('http://localhost:5000/Users/Editar',
            {
                method: 'PUT'
                , body: JSON.stringify({
                    id: this.state.id
                    , url: this.state.url
                    , login: this.state.login
                    , senha: this.state.senha
                }),
                headers: {}
            })
            .then(resposta => resposta,
                this.setState({ erro: "Usuário alterado com sucesso!!" }))
            .catch(erro => console.log(erro))
    }



    render() {
        return (
            <div className="caixa">
                <form >
                    <label >
                        <input type="text" placeholder="URL Zabbix" value={this.state.url} onChange={this.atualizaUrl.bind(this)}></input>
                        <input type="text" placeholder="Usuario" value={this.state.login} onChange={this.atualizaLogin.bind(this)}></input>
                        <input type="password" placeholder="Senha" value={this.state.senha} onChange={this.atualizaSenha.bind(this)}></input>
                    </label>
                    <button type="Submit" className="box-button" onSubmit={this.editaUsuario.bind(this)}>Finalizar</button>
                </form>
            </div>
        )
    }
}
export default Editar;